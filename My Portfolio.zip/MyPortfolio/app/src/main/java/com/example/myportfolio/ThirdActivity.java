package com.example.myportfolio;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ThirdActivity extends AppCompatActivity implements android.widget.PopupMenu.OnMenuItemClickListener {

    private int REQUEST_IMAGE_CAPTURE ;
    ImageView image;
    TextView textMenu;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_third);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        image = findViewById(R.id.imgV);
        textMenu = findViewById(R.id.tvMenu);
        registerForContextMenu(textMenu);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        String status = "Your option ";
        switch (item.getItemId())
        {
            case R.id.menu_email: status = "Email";
                break;
            case R.id.menu_camera: openCamera();
                break;
            case R.id.menu_exit: exitApp();
                break;
        }
        Toast.makeText(getApplicationContext(), status + " was clicked", Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable
    Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK)
        {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            image.setImageBitmap(imageBitmap);
        }
    }
    public void openCamera()
    {
        Intent cInt = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cInt, REQUEST_IMAGE_CAPTURE);
    }
    public void exitApp()
    {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(ThirdActivity.this);
        myAlertDialog.setTitle("Exit this application");
        myAlertDialog.setMessage("Are you sure to exit?");

        myAlertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        myAlertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(ThirdActivity.this, "Thank you for your support",
                        Toast.LENGTH_SHORT).show();
            }
        });
        myAlertDialog.show();
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item)
    {
        String str = "";
        switch(item.getItemId())
        {
            case R.id.menu_copy: str = "Copy";
                break;

            case R.id.menu_paste: str = "Paste";
                break;
            case R.id.menu_share: str = "Share";
                break;
        }
        Toast.makeText(getApplicationContext(), str + " is clicked.",
                Toast.LENGTH_SHORT).show();
        return super.onContextItemSelected(item);
    }
    public void popUp(View view)
    {
        PopupMenu popup = new PopupMenu(this, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.popup_menu, popup.getMenu());
        popup.show();
    }
    @Override
    public boolean onMenuItemClick(MenuItem menuItem)
    {
        String str = "";
        switch(menuItem.getItemId())
        {
            case R.id.pop_share: str = "Share";
                break;
            case R.id.pop_copy: str = "Copy";
                break;
            case R.id.pop_cut: str = "Cut";
                break;
        }
        Toast.makeText(getApplicationContext(), str + " is clicked.",
                Toast.LENGTH_SHORT).show();
        return false;
    }
    public void next(View view){
        Intent intent = new Intent(ThirdActivity.this,fouthActivity.class);
        startActivity(intent);
    }
}