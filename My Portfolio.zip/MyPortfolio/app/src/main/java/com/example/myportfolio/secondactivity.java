package com.example.myportfolio;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class secondactivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;

    private static final int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_secondactivity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mediaPlayer = MediaPlayer.create(this,
                R.raw.bohongi);
    }

    public void sendMail(View view)
    {
        Intent it = new Intent(Intent.ACTION_SEND);
        it.putExtra(Intent.EXTRA_EMAIL, new String[]
                {"faznita.ismail@ktd.edu.my"});
        it.putExtra(Intent.EXTRA_SUBJECT, "Aduan");
        it.putExtra(Intent.EXTRA_TEXT,"Assalamualaikum.....\nMohon ambil tindakan.");
                it.setType("text/Plain");
        startActivity(Intent.createChooser(it, "Send mail...."));
    }
    public void gallery(View view)
    {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }
    public void chatGPT(View view)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://openai.com/index/chatgpt/"));
        startActivity(intent);
    }
    public void callPhone(View view)
    {
        try
        {

             {
                Intent callIntent = new
                        Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:0194652497"));
                startActivity(callIntent);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
    public void audioPlay(View view)
    {
        mediaPlayer.start();
    }
    public void audioPause(View view)
    {
        mediaPlayer.pause();
    }
    public void audioStop(View view)
    {
        mediaPlayer.stop();
        mediaPlayer.reset();
        mediaPlayer = MediaPlayer.create(this,
                R.raw.bohongi);
    }

    public void openMap(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/XgYPXUwnBEtWyMir8"));
        startActivity(intent);
    }
 public void next(View view){
        Intent intent = new Intent(secondactivity.this,ThirdActivity.class);
        startActivity(intent);
 }
}